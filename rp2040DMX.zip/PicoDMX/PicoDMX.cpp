#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"
#include "pico/stdlib.h"
#include "DmxOutput.cpp"

#define NUM_LED1 50

#define LED1 15
#define LED2 26
#define LED3 27
#define LED4 28
#define LED5 29

#define D_ENABLE1 7
#define D_ENABLE2 8

typedef struct rgb_color {
  uint8_t Red, Green, Blue, White;
} rgb_color;

int seq = 0, pos = 0;
int i = 0, j = 0, l = 0;
uint8_t hue=0;
bool blink=false;
rgb_color sequence[800];

DmxOutput dmxOutputs;
#define UNIVERSE_LENGTH 512
uint8_t universe[UNIVERSE_LENGTH + 1];

void set_led(bool val);
void dmx_send();
void color_seguidor(uint8_t h, uint8_t s, uint8_t v) ;
rgb_color HsvToRgb(unsigned char H, unsigned char S, unsigned char V);

int main()
{
    stdio_init_all();
    gpio_init(LED1);
    gpio_init(D_ENABLE1);
    gpio_init(D_ENABLE2);
    gpio_set_dir(LED1, GPIO_OUT);
    gpio_set_dir(D_ENABLE1, GPIO_OUT);
    gpio_set_dir(D_ENABLE2, GPIO_OUT);
    gpio_put(D_ENABLE1, true);
    gpio_put(D_ENABLE2, true);

    dmxOutputs.begin(0, pio0);

    while (true) {
        color_seguidor(hue++,255,255);
    }
}



void set_led(bool val)
{
    gpio_put(LED1, val);
}

void dmx_send() {
    dmxOutputs.write(universe, UNIVERSE_LENGTH + 1);
    while (dmxOutputs.busy());
}

void color_seguidor(uint8_t h, uint8_t s, uint8_t v) {
  sequence[pos] = HsvToRgb(h, s, v);
  memcpy(universe + 1, &sequence[0], 4 * NUM_LED1);
  dmx_send();
  pos = pos + 1;

  if (pos == NUM_LED1) {
    pos = 0;
    blink =!blink;
    gpio_put(LED1, blink);
  }
}


rgb_color HsvToRgb(unsigned char H, unsigned char S, unsigned char V) {
  rgb_color rgb;
  unsigned char region;
  unsigned char remainder;
  unsigned char p;
  unsigned char q;
  unsigned char t;

  if (S == 0) {
    rgb.Red = V;
    rgb.Green = V;
    rgb.Blue = V;
    return rgb;
  }

  region = H / 43;
  remainder = (H - (region * 43)) * 6;

  p = (V * (255 - S)) >> 8;
  q = (V * (255 - ((S * remainder) >> 8))) >> 8;
  t = ((V * (255 - ((S * (255 - remainder)) >> 8))) >> 8);

  switch (region) {
    case 0:
      rgb.Red = V;
      rgb.Green = t;
      rgb.Blue = p;
      break;
    case 1:
      rgb.Red = q;
      rgb.Green = V;
      rgb.Blue = p;
      break;
    case 2:
      rgb.Red = p;
      rgb.Green = V;
      rgb.Blue = t;
      break;
    case 3:
      rgb.Red = p;
      rgb.Green = q;
      rgb.Blue = V;
      break;
    case 4:
      rgb.Red = t;
      rgb.Green = p;
      rgb.Blue = V;
      break;
    default:
      rgb.Red = V;
      rgb.Green = p;
      rgb.Blue = q;
      break;
  }

  return rgb;
}

